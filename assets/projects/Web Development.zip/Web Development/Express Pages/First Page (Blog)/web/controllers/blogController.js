var fs = require('fs');
var data = fs.readFileSync('models/blog.json');

if (data.length > 0) {
  var blog = JSON.parse(data);
} else {
  var blog = [];
}

function handleFiles(fileinput) {
  let file = fileinput;
  file.mv('public/uploads/' + file.name);
  return 'uploads/' + file.name;
}

const getAllPosts = (req,res) => {
  res.render('blog', { title: 'Mein Blog', blog});
    //res.send(blog);
}

const createPost = (req,res) => {
    let filename = '';
    if(req.files){
      filename = handleFiles(req.files.file);
    }
    let post = {
      id: blog.length ? blog[blog.length -1].id + 1 : 0,
      title: req.body.title,
      user: req.body.user,
      date: req.body.date,
      text: req.body.text,
      file: filename
    }
    blog.push(post);
    fs.writeFileSync('models/blog.json', JSON.stringify(blog, null, 2));
    res.redirect('/blog');
}

const getPost = (req,res) => {
    let post = blog.find(p => p.id === parseInt(req.params.id))
  if (post) {
    res.render('viewpost', { title: post.title , post});
  } else {
    res.send("Post existiert nicht");
  }
}

module.exports = {
    getAllPosts,
    createPost,
    getPost
}