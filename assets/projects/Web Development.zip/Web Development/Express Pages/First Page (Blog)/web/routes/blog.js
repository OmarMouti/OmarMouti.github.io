var express = require('express');
var router = express.Router();
var fs = require('fs');
var data = fs.readFileSync('models/blog.json');
var blogController = require('../controllers/blogController.js');

if (data.length > 0) {
  var blog = JSON.parse(data);
} else {
  var blog = [];
}

function handleFiles(fileinput) {
  let file = fileinput;
  file.mv('public/uploads/' + file.name);
  return 'uploads/' + file.name;
}

/* http://localhost/blog/ */
router.route('/')
  .get(blogController.getAllPosts)
  .post(blogController.createPost)

/* http://localhost/blog/neuerPost */
router.get('/neuerPost', function (req, res, next) {
  let formSubmits = {action: "/blog", method: "post", enctype: "multipart/form-data", submitValue: "Senden"};
  let formInputs = [
    { label: "Titel", type: "text", name:"title", required: true},
    { label: "Name", type: "text", name:"name", required: true},
    { label: "Datum", type: "date", name:"date", required: true},
    { label: "Text", type: "textarea", name:"text", required: true, rows:"4", cols:"cols"},
    { label: "Datei", type: "file", name:"file", required: false},
  ]

  res.render('blogpost', { title: 'Mein neuer Post', formSubmits, formInputs});
});

/* http://localhost/blog/* */
router.get('/:id', blogController.getPost);

module.exports = router;
