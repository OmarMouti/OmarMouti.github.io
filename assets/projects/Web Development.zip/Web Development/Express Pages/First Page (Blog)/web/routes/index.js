var express = require('express');
var router = express.Router();

/* http://localhost/ */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Web' , link: 'http://localhost/omar' });
});

/* http://localhost/omar */
router.get('/omar', function(req, res, next) {
  res.render('index', { title: 'Hi there' , link: 'http://localhost/' });
});

/* http://localhost/person */
router.get('/person', function(req, res, next) {
  res.render('person', { title: 'Formular' });
});

router.post('/neueperson', function(req, res, next) {
  console.log(req.body.geb);
  let geb = new Date(req.body.geb).getTime();
  let now = new Date(Date.now()).getTime();

  let diff = Math.round((now-geb) / (1000*60*60*24));
  
  console.log(diff);
  res.send("So true");
});
module.exports = router;
