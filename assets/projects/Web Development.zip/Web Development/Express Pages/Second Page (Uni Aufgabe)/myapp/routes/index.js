var express = require('express');
var router = express.Router();


// Wenn ein Benutzer zur Root-URL der app navigiert, antwortet er mit 
// der Darstellung der „Index“ View und übergibt den Titel und Buttons.

router.get('/', (req, res) => {
  const buttons = [
    { text: 'Go to Caesar Cipher page', route: '/caesar' },
    { text: 'Go to Matrix page', route: '/matrix' },
    { text: 'Go to BMI Page', route: '/bmi' },
  ];

  res.render('index', { title: 'Home', buttons: buttons, });
});

// Render Funktion wird verwendet um Views darzustellen und den HTML-Code als Antwort zu senden.

router.get('/caesar', (req, res) => {
  res.render('caesar', {
    title: 'Caesar',
  });
});

router.get('/matrix', (req, res) => {
  res.render('matrix', {
    title: 'Matrix',
  });
});

router.get('/bmi', (req, res) => {
  res.render('bmi', {
    title: 'BMI',
  });
});


module.exports = router;
