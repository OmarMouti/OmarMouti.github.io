var express = require('express');
var router = express.Router();

  
router.post('/calculate', (req, res) => {
    const weight = parseFloat(req.body.weight);
    const height = parseFloat(req.body.height) / 100; // Convert cm to m.
    const bmi = (weight / (height * height)).toFixed(2);

    // Send the BMI value as plain text
    res.send(bmi);
});

module.exports = router;
