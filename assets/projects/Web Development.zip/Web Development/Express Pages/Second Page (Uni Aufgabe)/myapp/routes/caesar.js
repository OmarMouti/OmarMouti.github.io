var express = require('express'); // importiert die Express-Bibliothek
var router = express.Router(); // erstellt eine Instanz eines Express-Routers

router.post('/autoFindKey', (req, res) => {
    const encryptedMessage = req.body.encryptedMessage; // Es ruft eine verschlüsselte Text aus dem Anfragetext ab.
    const key = findKey(encryptedMessage); //Es verwendet die Funktion findKey(), um den Schlüssel 
                                           // zum Entschlüsseln der Text zu ermitteln.
    res.send(key.toString()); // Schließlich sendet es den Schlüssel als Antwort zurück an den Client.
});

router.post('/decryptWithAutoKey', (req, res) => {
    const encryptedMessage = req.body.encryptedMessage; //  Es ruft eine verschlüsselte Text aus dem Anfragetext ab.
    const key = findKey(encryptedMessage); // Es verwendet die Funktion findKey(), um den Entschlüsselungsschlüssel zu finden.
    const decryptedMessage = decrypt(encryptedMessage, key); // Anschließend wird die Funktion decrypt() verwendet, 
                                                             // um die Text mithilfe des gefundenen Schlüssels zu entschlüsseln.
    res.send(decryptedMessage); // Schließlich sendet es die entschlüsselte Text als Antwort zurück an den Client.

});

router.post('/decryptWithManualKey', (req, res) => {
    const encryptedMessage = req.body.encryptedMessage; // Es ruft eine verschlüsselte Text und einen manuellen Schlüssel aus dem Anfragetext ab.
    const key = parseInt(req.body.manualKey); // Es verwendet die Funktion decrypt(), um die Text mit dem bereitgestellten manuellen Schlüssel zu entschlüsseln.
    const decryptedMessage = decrypt(encryptedMessage, key); // Schließlich sendet es die entschlüsselte Text als Antwort zurück an den Client.
    res.send(decryptedMessage);
});

function decrypt(encryptedMessage, shiftKey) {
    var alpha = "abcdefghijklmnopqrstuvwxyz";
    encryptedMessage = encryptedMessage.toLowerCase();
    var decryptedText = "";

    for (var i = 0; i < encryptedMessage.length; i++) { // läuft durch jedes Zeichen in der verschlüsselten Text
        var currentChar = encryptedMessage[i]; // ruft das aktuelle Zeichen ab das in der Schleife verarbeitet wird

        if (/^[a-z]$/.test(currentChar)) { // wenn das aktuelle Zeichen ein Kleinbuchstabe ist
            var chartPosition = alpha.indexOf(currentChar); // findet die Position des aktuellen Zeichens im Alphabet
            var keyVal = (chartPosition - shiftKey + 26) % 26; // berechnet die neue Position im Alphabet durch Addition der shiftkey

            // Durch Hinzufügen von +26 vor der Modulo-Operation wird sichergestellt, 
            // dass das Ergebnis im Bereich von 0 bis 25 angepasst wird, sodass die Modulo-Operation % 26 
            // korrekt funktioniert und die richtige verschlüsselte Position ergibt

            var replaceVal = alpha.charAt(keyVal); // ruft das entschlüsselte Zeichen aus dem Alphabet ab
            decryptedText += replaceVal; // hängt das entschlüsselte Zeichen an den entschlüsselten Text an
        } else {
            decryptedText += currentChar; // wenn das Zeichen kein Kleinbuchstabe ist
                                          // bleibt es unverändert und wird direkt an den entschlüsselten Text angehängt
        }
    }

    return decryptedText;
}

// Diese Funktion versucht, den Schlüssel zu finden, der zum Verschlüsseln einer Text verwendet wird.
// Es analysiert die Häufigkeitsverteilung von Buchstaben im verschlüsselten Text und vergleicht sie mit erwarteten Häufigkeiten 
// in der deutschen Sprache, um den am besten passenden Schlüssel zu finden.

function findKey(encryptedMessage) {
    var alpha = "abcdefghijklmnopqrstuvwxyz";
    encryptedMessage = encryptedMessage.toLowerCase();

    var germanFrequencies = {
        'a': 7.97, 'b': 1.54, 'c': 3.73, 'd': 5.58, 'e': 16.40,
        'f': 2.24, 'g': 3.57, 'h': 4.18, 'i': 7.55, 'j': 0.27,
        'k': 1.21, 'l': 3.44, 'm': 2.58, 'n': 9.84, 'o': 3.05,
        'p': 0.67, 'q': 0.02, 'r': 7.27, 's': 6.99, 't': 6.15,
        'u': 4.35, 'v': 0.67, 'w': 1.89, 'x': 0.03, 'y': 0.04, 'z': 1.13
    };

    var bestKey = 0;
    var minDifference = Infinity;

// diese Schleife iteriert durch alle möglichen Schlüssel (von 0 bis 25)

    for (var key = 0; key < 26; key++) { 
        var decryptedText = decrypt(encryptedMessage, key);
        var textFrequencies = {};

// zählst die Häufigkeit der Buchstaben in der entschlüsselten Text, wobei nur Buchstaben im Bereich von a-z betrachtet werden.

        for (var i = 0; i < decryptedText.length; i++) {
            var char = decryptedText[i];
            if (/^[a-z]$/.test(char)) {
                textFrequencies[char] = (textFrequencies[char] || 0) + 1;
            }
        }

        // vergleicht dann die beobachteten Buchstaben häufigkeiten (textFrequencies) mit den erwarteten Frequenzen 
        // für die deutsche Sprache (germanFrequencies) und berechnet die Gesamtdifferenz

        var difference = 0;
        for (var letter in germanFrequencies) {
            var observedFrequency = (textFrequencies[letter] || 0) / decryptedText.length * 100;
            difference += Math.abs(germanFrequencies[letter] - observedFrequency);
        }

        // der Schlüssel der die geringste Differenz zwischen den erwarteten und beobachteten Häufigkeiten aufweist, 
        // wird als potenziell bester Schlüssel (bestKey) gespeichert

        if (difference < minDifference) {
            minDifference = difference;
            bestKey = key;
        }
    }

    return bestKey;
}

// module.exports exportiert das Router-Objekt, sodass es importiert und von anderen Teilen der Anwendung verwendet werden kann.

module.exports = router;
