var express = require('express');
var router = express.Router();

router.post('/computeDCT', (req, res) => {
    const matrixInput = req.body.matrixInput;
    const matrixRows = matrixInput.trim().split("\n");
    const matrix = matrixRows.map(row => row.split(" ").map(Number));

    const dctResult = computeDCT(matrix);

    // Round the DCT values to the nearest natural integer

    const roundedDCTResult = dctResult.map(row => row.map(val => Math.round(val))); // rundet die wert auf die nachste ganze zahl
    const dctResultText = roundedDCTResult.map(row => row.join("\t")).join("\n"); // konvertiert den matrix integer zu text

    res.send(dctResultText); // Send the DCT result as a response
});

// Functions computeDCT and other helper functions can be placed here

function computeDCT(matrix) {
    const dctMatrix = [];
    // diese Schleifen durchlaufen die Output DCT-Matrix
    for (let u = 0; u < 8; u++) {
        const dctRow = [];
        for (let v = 0; v < 8; v++) {
            let sum = 0;
            // // diese Schleifen durchlaufen die Input DCT-Matrix
            for (let j = 0; j < 8; j++) {
                for (let k = 0; k < 8; k++) {
                    const Cu = u === 0 ? 1 / Math.sqrt(2) : 1; // wenn u ist 0 gibt an const Cu den wert 1 / Math.sqrt(2), ansonst gibt 1 an.
                    const Cv = v === 0 ? 1 / Math.sqrt(2) : 1;
                    sum += matrix[j][k] * Cu * Cv * Math.cos(((2 * j + 1) * u * Math.PI) / 16) * Math.cos(((2 * k + 1) * v * Math.PI) / 16);
                }
            }
            dctRow.push((1 / 4) * sum);
        }
        dctMatrix.push(dctRow);
    }
    return dctMatrix;
}

module.exports = router;
