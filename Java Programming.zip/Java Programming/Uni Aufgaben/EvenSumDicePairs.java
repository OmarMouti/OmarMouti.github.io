public class EvenSumDicePairs {
    public static void main(String[] args) {
        int a;
        int b;

        for (a = 1; a <= 6; ++a) {
            for (b = 1; b <= 6; ++b) {
                if (a <= b && (a + b) % 2 == 0) {
                    System.out.println((a+","+b));
                }
            }
        }
    }
}
