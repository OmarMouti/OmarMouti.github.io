import java.util.Scanner;

public class PerfectGroups {
    public static void main(String[] args) {
        System.out.println("Geben Sie die Anzahl an Personen ein: ");
        Scanner in = new Scanner(System.in);
        int anzahl = in.nextInt();
        if (anzahl % 2 == 0) {
            System.out.println("Personen werden auf " + anzahl / 2 + " Gruppen geteilt \nPerfekt Aufteilung ");
        } else {
            System.out.println("Personen werden auf " + anzahl / 2 + " Gruppen geteilt");
        }
    }
}
