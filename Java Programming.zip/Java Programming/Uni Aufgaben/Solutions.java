import java.util.ArrayList;
import java.util.List;

public class Solutions {
    public static void main(String[] args) {
        int x;
        List<Integer> solutions = new ArrayList<Integer>();
        for (x = 0; x < 100; x++) {
            if (x * x * x - 73 * x * x + 1655 * x - 11951 == 0) {
                solutions.add(x);
            }
        }
        System.out.println("Die Lösungen sind: " + solutions);
    }
}
