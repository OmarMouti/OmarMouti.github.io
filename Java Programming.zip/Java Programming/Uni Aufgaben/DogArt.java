public class DogArt {
    public static void main(String[] args){
        System.out.println("   ______________________ \n" +
                " <  Mein Name ist Olaf >\n" +
                "   ----------------------\n" +
                " / \\__          /\n" +
                "(     @\\___    /\n" +
                " /         O\n" +
                "/  (_____/ \n" +
                "/_____/ U");
    }
}
