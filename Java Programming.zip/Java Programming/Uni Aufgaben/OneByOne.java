import java.util.Scanner;

public class OneByOne {
    public static void main(String[] args) {
        System.out.println("Geben Sie ein Zahl: ");
        Scanner zahl = new Scanner(System.in);
        int z = zahl.nextInt();
        int sum = 0;

        while ( z > 0 ){

            sum += z & 1;
                            // The bitwise operators directly manipulate the binary representation
                            // of integers without needing to converting the number to a binary string.

            z = z >> 1;     // This line gets rid of the bit we just isolated and checked (the far right) and moves
                            // the binary representation of the number by one bit to the right. It is repeated until
                            // all bits are moved and only 0 remains then the loops stops.
        }

        System.out.println("The number of ones is: " + sum);
    }
}

//        while (z > 0) {
//        int rest = z % 2;
//        if (rest == 1) {
//        sum += 1;
//        }
//        z = z / 2;
