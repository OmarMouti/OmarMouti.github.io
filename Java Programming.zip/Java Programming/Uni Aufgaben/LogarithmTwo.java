public class LogarithmTwo {
    public static void main(String[] args) {
        double ln = 0;
        int i = 1;
        double w = 0.0023;
        double lowerRange = Math.log(2) - w;
        double higherRange = Math.log(2) + w;

        while (true) {
            ln += -1 * (Math.pow(-1, i) / i);

            if (ln >= lowerRange && ln <= higherRange) {
                break;
            }

            i++;
        }
        System.out.println("Die Referenzwert von Ln(2) ist: " + Math.log(2));
        System.out.println("Die berechnete Näherungslösung von ln(2) ist: " + ln);
        System.out.println("Die Anzahl benötigter Summanden ist: " + i);
    }
}
