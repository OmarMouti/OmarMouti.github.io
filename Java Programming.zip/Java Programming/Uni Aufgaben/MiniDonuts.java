import java.util.Scanner;

public class MiniDonuts {
    public static void main(String[] args) {
        System.out.println("Wie viel Minidonuts wollen Sie einkaufen? ");
        Scanner zahl = new Scanner(System.in);
        int n = zahl.nextInt();
        System.out.println("Wie viel Großpackungen gibt es? ");
        Scanner gross = new Scanner(System.in);
        int big = gross.nextInt();
        System.out.println("Wie viel Einzelpackungen: ");
        Scanner klein = new Scanner(System.in);
        int small = klein.nextInt();

        int bigSize = big * 5;
        int neededSmall = n % 5;

        // Beispiel 1: genug Donuts in Großpackungen und genug Einzelpackungen fur den Rest
        if (n <= bigSize && neededSmall <= small) {
            System.out.println("Sie mussen " + n / 5 + " Großpackungen und " + (neededSmall) + " Einzelpackungen kaufen");
            // Beispiel 2: nicht genug Donuts in Großpackungen, aber genug Einzelpackungen fur den Rest
        } else if (n > bigSize && neededSmall <= small && (n - bigSize) <= small) {
            System.out.println("Sie mussen " + big + " Großpackungen und " + (n - bigSize) + " Einzelpackungen kaufen");
            // Beispiel 3 und 4: entweder nicht genug Großpackungen UND Einzelpackungen oder genug Großpackungen aber nicht genug Einzelpackungen
        } else {
            System.out.println("Geht nicht!");
        }
    }
}
