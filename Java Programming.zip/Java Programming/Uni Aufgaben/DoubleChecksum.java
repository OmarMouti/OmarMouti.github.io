import java.util.Scanner;

public class DoubleChecksum {
    public static void main(String[] args) {
        System.out.println("Geben Sie die Zahl ein: ");
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int summe = n%100;
        while (n/100>0){
            n = n/100;
            summe += n%100;
        }
        System.out.println("Die Zweier-Quersumme ist: " + summe);
    }
}
