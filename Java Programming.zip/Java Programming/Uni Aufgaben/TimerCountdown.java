

public class TimerCountdown {

    public static void main(String[] args) {
        // Zählerwert Timer int
        // solange Timer > 0
        // Timer um eins runterzählen
        int timer = 100;
        while (timer > 0) {
            timer = timer - 1;
            System.out.println("Time is " + timer);
        }
        System.out.println("Timer is zero");


    }
}
